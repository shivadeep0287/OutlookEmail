﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Outlook;
using System.Net;
using Aspose.Email.Clients.Exchange.WebService;
using Aspose.Email.Clients.Exchange;

namespace OutlookEmail
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadEmail();
            //const string mailboxUri = "";
            //const string domain = @"";
            //const string username = @"username";
            //const string password = @"password";
            //NetworkCredential credentials = new NetworkCredential(username, password, domain);
            //IEWSClient client = EWSClient.GetEWSClient(mailboxUri, credentials);

            //return client;
        }

        public static void ReadEmailFromExchangeServer()
        {

        }

        public static void ReadEmail()
        {
            Application outlookApplication = null;
            NameSpace outlookNamespace = null;
            MAPIFolder inboxFolder = null;
            Items mailItems = null;

            try
            {
                outlookApplication = new Application();
                outlookNamespace = outlookApplication.GetNamespace("MAPI");
                inboxFolder = outlookNamespace.GetDefaultFolder(OlDefaultFolders.olFolderInbox); //outlookNamespace.Folders["sbhaskar@sg.palo-it.com"].Folders["Inbox"];//
                mailItems = inboxFolder.Items;

                Console.WriteLine(mailItems.Count);

                foreach (MailItem item in mailItems)
                {
                    var stringBuilder = new StringBuilder();
                    stringBuilder.AppendLine("From: " + item.SenderEmailAddress);
                    stringBuilder.AppendLine("To: " + item.To);
                    stringBuilder.AppendLine("CC: " + item.CC);
                    stringBuilder.AppendLine("");
                    stringBuilder.AppendLine("Subject: " + item.Subject);
                    stringBuilder.AppendLine(item.Body);

                    Console.WriteLine(stringBuilder);
                    Marshal.ReleaseComObject(item);
                }
            }
            //Error handler.
            catch (System.Exception e)
            {
                Console.WriteLine("{0} Exception caught: ", e);
            }
            finally
            {
                ReleaseComObject(mailItems);
                ReleaseComObject(inboxFolder);
                ReleaseComObject(outlookNamespace);
                ReleaseComObject(outlookApplication);
            }

            Console.WriteLine("OK");
            Console.ReadKey();
        }
        private static void ReleaseComObject(object obj)
        {
            if (obj != null)
            {
                Marshal.ReleaseComObject(obj);
                obj = null;
            }
        }
    }
}
