﻿using Aspose.Email.Clients.Exchange;
using Aspose.Email.Clients.Exchange.WebService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace OutlookEmail
{
    class Email
    {
        private static IEWSClient GetExchangeEWSClient()
        {
            //const string mailboxUri = "https://outlook.office365.com/";
            //const string domain = @"";
            //const string username = @"username";
            //const string password = @"password";
            //NetworkCredential credentials = new NetworkCredential(username, password, domain);
            //IEWSClient client = EWSClient.GetEWSClient(mailboxUri, credentials);
            //return client;


            IEWSClient client = EWSClient.GetEWSClient("https://outlook.office365.com/", "username", "password");

            // Call ListMessages method to list messages info from Inbox
            ExchangeMessageInfoCollection msgCollection = client.ListMessages(client.MailboxInfo.InboxUri);

            // Loop through the collection to display the basic information
            foreach (ExchangeMessageInfo msgInfo in msgCollection)
            {
                Console.WriteLine("Subject: " + msgInfo.Subject);
                Console.WriteLine("From: " + msgInfo.From.ToString());
                Console.WriteLine("To: " + msgInfo.To.ToString());
                Console.WriteLine("Message ID: " + msgInfo.MessageId);
                Console.WriteLine("Unique URI: " + msgInfo.UniqueUri);
            }
            return client;
        }
    }
}
