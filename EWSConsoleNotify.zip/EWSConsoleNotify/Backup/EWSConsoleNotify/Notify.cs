﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace EWSConsoleNotify
{
    public class Notify
    {
        private ExchangeService _service;
        private TcpListener _listener;
        private Thread _th;
        

        public string SubscriptionId { get; set; }

        public string Name
        {
            get
            {
                return "EWSConsoleNotify";
            }
        }

        public void WriteLog(string Message)
        {
            Console.WriteLine(Message);
        }

        public void ShowMessage(string UniqueId)
        {
            EmailMessage mail = ((EmailMessage)Item.Bind(_service, new ItemId(UniqueId)));

            Console.WriteLine("New mail from: {0}, Subject: {1}", mail.From.Name, mail.Subject);
        }

        public void Start()
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate(
                Object obj,
                X509Certificate certificate,
                X509Chain chain,
                SslPolicyErrors errors)
            {
                return true;
                // TODO: check for a valid certificate
            };

            // Create the subscription
            _service = new ExchangeService();
            // Set credentials: user, password and domain
            _service.Credentials = new WebCredentials("user", "password", "domain");
            // URL of the EWS
            _service.Url = new Uri("https://exchange_server/ews/exchange.asmx");

            PushSubscription ps = _service.SubscribeToPushNotificationsOnAllFolders(new Uri("http://your_IP:5050"),
                5 // Every 5 minutes Exchange will send us a status message
                , null, EventType.NewMail);

            SubscriptionId = ps.Id;

            // Listen on port 5050
            _listener = new TcpListener(5050);
            _listener.Start();

            _th = new Thread(new ThreadStart(ProcessIncomingMessages));
            _th.Start();

            WriteLog("Listening for incomming messages...");
        }


        public void Stop()
        {
            _th.Abort();
            _listener.Stop();
        }


        private void ProcessIncomingMessages()
        {
            for (; ; )
            {
                CSHTTPRequest csHttpRequest = new CSHTTPRequest(_listener.AcceptTcpClient(), this);

                csHttpRequest.Process();
            }
        }
    }
}
