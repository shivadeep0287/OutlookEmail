﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EWSConsoleNotify
{
    class Program
    {
        static void Main(string[] args)
        {
            Notify myNotify = new Notify();

            myNotify.Start();
            Console.ReadKey();
            myNotify.Stop();
        }
    }
}
